var swiper = new Swiper(".mySwiper", {
	autoplay: {
		delay: 4000,
		disableOnInteraction: false
	},
	pagination: {
		el: ".swiper-pagination",
		clickable: true
	},
	rewind: true
});
